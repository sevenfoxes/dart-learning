# Startup Namer

Created for a Google I/O 2017 codelab, this AngularDart app smashes together
words, helping you brainstorm ideas for your naming your next startup.

More information:
* Codelab: [Write a Material Design AngularDart Web App](https://codelabs.developers.google.com/codelabs/your-first-angulardart-web-app/)
* Documentation: [AngularDart](https://webdev.dartlang.org/angular),
  [AngularDart Components](https://webdev.dartlang.org/components)

See LICENSE.
